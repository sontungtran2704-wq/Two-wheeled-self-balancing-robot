'use strict';
const test=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path'),http=require('node:http');
const {chromium}=require(process.env.PLAYWRIGHT_MODULE||'C:/Users/DELL/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright');
test('direct phone page: calibration, hold/release, queued STOP, blur and lost Wi-Fi',async t=>{
 const header=fs.readFileSync(path.join(__dirname,'../../03_Firmware_ESP32_S3/balancebot/PhonePage.h'),'utf8');
 const html=header.split('R"PHONE(')[1].split(')PHONE"')[0];
 let st=0,cal=0,offline=false,delayStatus=false,delayDrive=false,last='QUEUED',seq=0;
 const commands=[],errors=[],external=[];
 const server=http.createServer((req,res)=>{
  res.setHeader('Cache-Control','no-store');
  if(req.url==='/'){res.setHeader('Content-Type','text/html; charset=utf-8');res.end(html);return;}
  if(req.url==='/session'){res.end('test-token');return;}
  if(req.headers['x-robot-token']!=='test-token'){res.writeHead(403).end();return;}
  if(req.url==='/status'){
   if(offline){req.socket.destroy();return;}
   const body=`t=${++seq*40},st=${st},session=42,seq=${seq},theta=0.01,v=0,fault=NONE,imu_calibrated=${cal},imu_diag=${cal?1:7},imu_cal_saved=${cal}\n${last}`;
   setTimeout(()=>res.end(body),delayStatus?350:0);return;
  }
  if(req.url==='/command'){
   let body='';req.on('data',d=>body+=d);req.on('end',()=>{commands.push(body);if(body==='STOP'||body==='ESTOP')st=0;if(body==='START')st=2;last=body==='CALGYRO'?'ACK:CALGYRO_PENDING':body.startsWith('CMD,')?'ACK:CMD':'ACK:'+body.split(',')[0];setTimeout(()=>res.writeHead(202).end('QUEUED'),delayDrive&&body.startsWith('CMD,')?200:0);});return;
  }
  res.writeHead(404).end();
 });
 await new Promise(r=>server.listen(0,'127.0.0.1',r));const url=`http://127.0.0.1:${server.address().port}`;
 const browser=await chromium.launch({channel:'msedge',headless:true});
 t.after(async()=>{await browser.close();await new Promise(r=>server.close(r));});
 const page=await browser.newPage({viewport:{width:390,height:844},isMobile:true,hasTouch:true});
 page.on('pageerror',e=>errors.push(e.message));page.on('request',r=>{if(!r.url().startsWith(url))external.push(r.url());});
 await page.goto(url);await page.waitForFunction(()=>document.querySelector('#data').textContent.includes('Cần hiệu chuẩn'));
 assert(await page.locator('#start').isDisabled());
 await page.locator('summary').click();await page.locator('[data-command="CALGYRO"]').click();
 await page.waitForFunction(()=>document.querySelector('#message').textContent.includes('CALGYRO_PENDING'));
 assert(await page.locator('#start').isDisabled(),'pending ACK must not permit START');
 cal=1;await page.waitForFunction(()=>!document.querySelector('#start').disabled);await page.locator('#start').click();
 await page.waitForFunction(()=>document.querySelector('#driveState').textContent.includes('Giữ nút'));
 const up=page.locator('[data-drive="up"]');await up.scrollIntoViewIfNeeded();const box=await up.boundingBox();
 await page.mouse.move(box.x+box.width/2,box.y+box.height/2);await page.mouse.down();
 await page.waitForFunction(()=>held==='up');await new Promise(r=>setTimeout(r,450));await page.mouse.up();
 await page.waitForFunction(()=>!held);await new Promise(r=>setTimeout(r,350));
 assert(commands.includes('MOTION,1'));assert(commands.some(c=>/^CMD,42,\d+,0\.0500,0\.0000$/.test(c)));assert(commands.some(c=>/^CMD,42,\d+,0\.0000,0\.0000$/.test(c)));
 delayDrive=true;const before=commands.length;await page.evaluate(()=>{held='up';pointer=7;});
 for(let i=0;i<40&&!commands.slice(before).some(c=>/^CMD,.*0\.0500/.test(c));i++)await new Promise(r=>setTimeout(r,25));
 assert(commands.slice(before).some(c=>/^CMD,.*0\.0500/.test(c)));await page.evaluate(()=>release());await new Promise(r=>setTimeout(r,650));
 assert(commands.slice(before).some(c=>/^CMD,42,\d+,0\.0000,0\.0000$/.test(c)),'release during in-flight drive must still send zero');delayDrive=false;
 await page.evaluate(()=>{held='up';pointer=3;window.dispatchEvent(new Event('blur'));});assert.equal(await page.evaluate(()=>held),'');
 delayStatus=true;await page.waitForFunction(()=>busy);await page.evaluate(()=>manual('STOP'));await page.waitForFunction(()=>latest.st==='0');assert(commands.includes('STOP'),'STOP must survive a busy status exchange');delayStatus=false;
 st=2;await page.waitForFunction(()=>latest.st==='2');await page.evaluate(()=>{held='up';pointer=1;});await new Promise(r=>setTimeout(r,200));offline=true;
 await page.waitForFunction(()=>document.querySelector('#link').textContent.includes('Mất liên lạc'));const count=commands.length;await new Promise(r=>setTimeout(r,600));assert.equal(commands.length,count,'no stale drive commands after loss');assert.equal(await page.evaluate(()=>held),'');
 offline=false;await page.waitForFunction(()=>document.querySelector('#link').textContent.includes('Đã nối'));await new Promise(r=>setTimeout(r,250));assert(!commands.slice(count).some(c=>/^CMD,.*0\.0500/.test(c)),'reconnect must not resume held drive');
 assert.equal(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth),true);assert.deepEqual(errors,[]);assert.deepEqual(external,[]);
 await page.screenshot({path:path.join(__dirname,'../../06_Kiem_tra/phone_web_20261114/phone-390.png'),fullPage:true});
});
