#ifdef NDEBUG
#undef NDEBUG
#endif
#include <cassert>
#include <cerrno>
#include <cstdint>
#include <cstring>
#include <string>
#include <iostream>
#include <algorithm>
static uint32_t clockMs=0;
uint32_t millis(){return clockMs;}
uint32_t esp_random(){return 0x12345678;}
constexpr int MSG_DONTWAIT=1;
struct Channel {bool live=false,candidate=false;std::string input,output;size_t rx=0;int chunk=37,fail=0;};
static Channel channel;
struct WiFiClient {
  bool connected(){return channel.live;}
  void stop(){channel.live=false;}
  void setNoDelay(bool){}
  int available(){return int(channel.input.size()-channel.rx);}
  int read(){return static_cast<unsigned char>(channel.input[channel.rx++]);}
  int fd(){return 1;}
};
struct WiFiServer {
  explicit WiFiServer(int){}
  void begin(){}
  bool hasClient(){return channel.candidate;}
  WiFiClient accept(){channel.candidate=false;return {};}
};
struct IP {std::string value;std::string toString(){return value;}};
struct Wifi {IP softAPIP(){return {"192.168.4.1"};}IP localIP(){return {"0.0.0.0"};}} WiFi;
int send(int,const char* p,size_t size,int){if(channel.fail){errno=channel.fail;return -1;}size=std::min(size,size_t(channel.chunk));channel.output.append(p,size);return int(size);}
#include "PhoneWeb.h"
static phone::Web web;
static std::string accepted;static unsigned calls=0;
void accept(const char* text,uint8_t source){assert(source==3);++calls;accepted=text;web.reply("ACK:TEST");}
void status(char* out,size_t cap){std::snprintf(out,cap,"t=123,session=1,st=0,imu_calibrated=0");}
std::string req(const std::string& method,const std::string& path,const std::string& body="",const std::string& token="12345678123456781234567812345678",const std::string& host="192.168.4.1") {
  return method+" "+path+" HTTP/1.1\r\nHost: "+host+"\r\nOrigin: http://"+host+"\r\nX-Robot-Token: "+token+"\r\nContent-Length: "+std::to_string(body.size())+"\r\n\r\n"+body;
}
std::string exchange(const std::string& text) {
  channel=Channel{};channel.live=channel.candidate=true;channel.input=text;
  for(unsigned n=0;n<1000&&channel.live;++n){web.poll();clockMs+=2;}
  assert(!channel.live);return channel.output;
}
phone::Request parse(const std::string& text){phone::Request r;for(char c:text)r.feed(c);return r;}
void validResponse(const std::string& text,const std::string& body){const auto split=text.find("\r\n\r\n");assert(split!=std::string::npos);assert(text.substr(split+4)==body);assert(text.find("Content-Length: "+std::to_string(body.size())+"\r\n")!=std::string::npos);}
int main(){
  web.begin(accept,status);
  auto r=parse(req("POST","/command","START"));assert(r.complete&&!r.error&&!std::strcmp(r.body(),"START"));assert(r.authorized("12345678123456781234567812345678"));
  assert(parse("POST /command HTTP/1.1\r\nHost: x\r\nContent-Length: 2\r\nContent-Length: 2\r\n\r\nOK").error==400);
  assert(parse("POST /command HTTP/1.1\r\nHost: x\r\nTransfer-Encoding: chunked\r\n\r\n").error==400);
  assert(parse("POST /command HTTP/1.1\r\nHost: x\r\nContent-Length: -1\r\n\r\n").error==400);
  assert(parse(req("POST","/command",std::string(161,'X'))).error==413);
  assert(parse("GET / HTTP/1.1\r\nHost: "+std::string(1100,'X')).error==431);
  assert(parse("POST /command HTTP/1.1\r\nHost: x\r\n\r\n").error==411);
  auto page=exchange(req("GET","/"));validResponse(page,phone::page);assert(page.find("http://cdn")==std::string::npos);
  auto session=exchange(req("GET","/session"));validResponse(session,"12345678123456781234567812345678");
  assert(exchange(req("POST","/command","START","bad")).find("403")!=std::string::npos);assert(!calls);
  assert(exchange(req("POST","/command","START","12345678123456781234567812345678","attacker.test")).find("403")!=std::string::npos);assert(!calls);
  auto foreign=req("POST","/command","START");foreign.replace(foreign.find("Origin: http://192.168.4.1"),24,"Origin: http://evil.test");assert(exchange(foreign).find("403")!=std::string::npos);assert(!calls);
  assert(exchange(req("POST","/command","START\nSTOP")).find("400")!=std::string::npos);assert(!calls);
  validResponse(exchange(req("POST","/command","START")),"ACK:TEST");assert(calls==1&&accepted=="START");
  web.reply("ACK:CALGYRO_PENDING");validResponse(exchange(req("GET","/status")),"t=123,session=1,st=0,imu_calibrated=0\nACK:CALGYRO_PENDING");
  // Backpressure must retain bytes, including partial header/body writes.
  channel=Channel{};channel.live=channel.candidate=true;channel.input=req("GET","/");channel.fail=EAGAIN;
  for(int n=0;n<10;++n){web.poll();clockMs+=2;}assert(channel.live&&channel.output.empty());channel.fail=0;
  for(int n=0;n<1000&&channel.live;++n){web.poll();clockMs+=2;}validResponse(channel.output,phone::page);
  channel=Channel{};channel.live=channel.candidate=true;channel.input=req("GET","/");channel.fail=EPIPE;web.poll();web.poll();assert(!channel.live);
  clockMs=0xfffffff0;channel=Channel{};channel.live=channel.candidate=true;channel.input="POST /command";web.poll();clockMs+=1600;web.poll();assert(!channel.live&&calls==1);
  // A new connection after timeout has no stale request or response bytes.
  validResponse(exchange(req("POST","/command","STOP")),"ACK:TEST");assert(calls==2&&accepted=="STOP");
  std::cout<<"PASS: bounded phone HTTP, exact offline page, token/Host/Origin checks, malformed/oversize rejection, command routing, truthful status, partial/EAGAIN TX, fatal/timeout/wrap recovery\n";
}
