'use strict';
const test=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path'),http=require('node:http'),zlib=require('node:zlib');
const {calculate}=require('../lqr');
const {chromium}=require(process.env.PLAYWRIGHT_MODULE||'C:/Users/DELL/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright');
test('desktop UI offline: press/release, charts, exports, calibration, PID, LQR ACK, lost Wi-Fi',async t=>{
 const root=path.join(__dirname,'../..'),out=path.join(root,'06_Kiem_tra/phone_desktop_20261114');
 const html=zlib.gunzipSync(fs.readFileSync(path.join(root,'.build/phone-page.html.gz'))).toString(),design=require('../../shared/design.json');
 for(const f of ['style.css','dashboard.js','button-feedback.js'])assert(html.includes(fs.readFileSync(path.join(root,'4_Web/public',f),'utf8')),f+' must be shared exactly');
 let st=0,cal=0,offline=false,delayStatus=0,delayDrive=0,holdLqr=false,reply='',replyId=0,tick=0,K=design.K.slice(),pid=[3,1,.2];
 const commands=[],errors=[],external=[],say=line=>{reply=line;replyId++;};
 const server=http.createServer((req,res)=>{
  res.setHeader('Cache-Control','no-store');
  if(req.url==='/'){res.setHeader('Content-Type','text/html; charset=utf-8');res.end(html);return;}
  if(req.url==='/session'){res.end('test-token');return;}
  if(req.url==='/icons/icon.svg'){res.setHeader('Content-Type','image/svg+xml');res.end('<svg xmlns="http://www.w3.org/2000/svg"/>');return;}
  if(req.url==='/manifest.json'){res.setHeader('Content-Type','application/json');res.end('{}');return;}
  if(req.headers['x-robot-token']!=='test-token'){res.writeHead(403).end();return;}
  if(req.url==='/status'){
   if(offline){req.socket.destroy();return;}
   const body=`t=${++tick*80},st=${st},session=42,seq=${tick},theta=0.01,omega=0,v=0.01,yaw=0,u=0.1,left=0,right=0,motion=1,fresh=1,sat=0,auto_mode=1,auto_wait=0,auto_ms=0,config=${design.config_id},hash=${design.config_sha256},fault=${st===3?'SPEED_RAIL':'NONE'},imu_calibrated=${cal},imu_diag=${cal?1:7},imu_cal_saved=${cal},imu_sample_fresh=1,hardware_confirmed=1,lqr2=1,phone_vkp=${pid[0]},phone_vki=${pid[1]},phone_vkd=${pid[2]},phone_k0=${K[0]},phone_k1=${K[1]}\nreply_id=${replyId}\n${reply}`;
   setTimeout(()=>res.end(body),delayStatus);return;
  }
  if(req.url==='/command'){
   let body='';req.on('data',d=>body+=d);req.on('end',()=>{commands.push(body);const p=body.split(',');
    setTimeout(()=>{
     if(body==='START'){if(cal){st=2;say('ACK:START');}else say('ERR:IMU');}
     else if(body==='STOP'||body==='ESTOP'){st=0;say('ACK:'+body);}
     else if(body==='GET')say(`t=1\nPID:V,${pid.join(',')}\nPID:Y,3,0.8,0.02\nLQR:${K.join(',')}`);
     else if(body==='CALGYRO')say('ACK:CALGYRO_PENDING');
     else if(p[0]==='$P'){pid=p.slice(2).map(Number);say('ACK:$P');}
     else if(p[0]==='LQR2'){if(!holdLqr){K=p.slice(2).map(Number);say('ACK:LQR2,'+K.join(','));}}
     else say('ACK:'+p[0]);
    },15);setTimeout(()=>res.writeHead(202).end('QUEUED'),p[0]==='CMD'?delayDrive:0);
   });return;
  }res.writeHead(404).end();
 });
 await new Promise(r=>server.listen(0,'127.0.0.1',r));const url=`http://127.0.0.1:${server.address().port}`;
 const browser=await chromium.launch({channel:'msedge',headless:true});t.after(async()=>{await browser.close();await new Promise(r=>server.close(r));});
 const page=await browser.newPage({viewport:{width:390,height:844},isMobile:true,hasTouch:true});
 page.setDefaultTimeout(10000);
 page.on('pageerror',e=>errors.push(e.message));page.on('request',r=>{if(!r.url().startsWith(url))external.push(r.url());});
 await page.goto(url);await page.waitForFunction(()=>document.querySelector('#state-display').textContent.includes('hiệu chuẩn'));
 await page.click('#btn-start');await page.waitForTimeout(150);assert(!commands.includes('START'));
 await page.locator('[onclick="robotCmd(\'calgyro\')"]').click();await page.waitForFunction(()=>[...document.querySelectorAll('.notification')].some(n=>n.textContent.includes('CALGYRO_PENDING')));assert.equal(st,0);
 cal=1;await page.waitForFunction(()=>robotState.imuCalibrated===1);await page.click('#btn-start');await page.waitForFunction(()=>robotState.st===2);await page.waitForTimeout(150);
 const up=page.locator('.drive-forward');await up.scrollIntoViewIfNeeded();let box=await up.boundingBox();
 const down=async()=>{await page.evaluate(()=>document.querySelectorAll('.notification').forEach(n=>n.remove()));await up.scrollIntoViewIfNeeded();await page.waitForTimeout(150);box=await up.boundingBox();await page.mouse.move(box.x+box.width/2,box.y+box.height/2);await page.mouse.down();};
 await down();await page.waitForFunction(()=>document.querySelector('.drive-forward').classList.contains('is-pressed'));assert.notEqual(await up.evaluate(e=>getComputedStyle(e).transform),'none');
 await page.waitForTimeout(600);await page.screenshot({path:path.join(out,'phone-held.png'),fullPage:false});await page.mouse.up();await page.waitForFunction(()=>!document.querySelector('.drive-forward').classList.contains('is-pressed'));await page.waitForTimeout(400);
 assert(commands.includes('MOTION,1'));assert(commands.some(c=>/^CMD,42,\d+,0\.050000,0\.000000$/.test(c)));assert(commands.some(c=>/^CMD,42,\d+,0\.000000,0\.000000$/.test(c)));
 delayDrive=180;const before=commands.length;await down();for(let i=0;i<40&&!commands.slice(before).some(c=>/^CMD,.*0\.050000/.test(c));i++)await page.waitForTimeout(25);await page.mouse.up();await page.waitForTimeout(700);assert(commands.slice(before).some(c=>/^CMD,42,\d+,0\.000000,0\.000000$/.test(c)));delayDrive=0;
 delayStatus=200;await page.click('#btn-stop');await page.waitForFunction(()=>robotState.st===0);delayStatus=0;
 await page.fill('#pid-kp','2.5');await page.fill('#pid-ki','0.9');await page.fill('#pid-kd','0.15');await page.locator('[onclick="sendPid()"]').click();await page.waitForFunction(()=>document.querySelector('#current-kp').textContent==='2.500');assert(commands.includes('$P,V,2.5,0.9,0.15'));
 for(const [Q,R] of [[[400,4],1],[[100,1],1],[[300,3],1],[[50,1],3]]){const actual=await page.evaluate(({Q,R})=>window.phoneCalculate(Q,R).K,{Q,R}),expected=calculate(Q,R).K;actual.forEach((x,i)=>assert(Math.abs(x-expected[i])<1e-12));}
 await page.fill('#q0-input','300');await page.fill('#q1-input','3');await page.fill('#r-input','1');holdLqr=true;await page.click('#btn-lqr');await page.waitForTimeout(2300);assert(!await page.evaluate(()=>lqrParams.Q?.[0]===300&&lqrParams.sentToRobot),'missing ACK must not claim new K');
 holdLqr=false;await page.click('#btn-lqr');await page.waitForFunction(()=>lqrParams.Q?.[0]===300&&lqrParams.sentToRobot===true);assert(commands.some(c=>c.startsWith('LQR2,')));
 await page.locator('[onclick="robotCmd(\'save\')"]').click();await page.waitForTimeout(200);assert(commands.includes('SAVE'));
 await page.locator('.mobile-nav-btn[data-panel="charts"]').click();await page.waitForFunction(()=>angleChart.data.labels.length>2);await page.evaluate(()=>document.querySelectorAll('.notification').forEach(n=>n.remove()));await page.waitForTimeout(100);await page.screenshot({path:path.join(out,'phone-charts.png'),fullPage:true});
 await page.locator('.mobile-nav-btn[data-panel="data"]').click();await page.waitForTimeout(100);assert(await page.locator('#panel-data').isVisible());await page.screenshot({path:path.join(out,'phone-data.png'),fullPage:true});
 await page.locator('.mobile-nav-btn[data-panel="controls"]').click();let download=page.waitForEvent('download');await page.locator('[onclick="exportCSV()"]').click();let file=await download;assert(file.suggestedFilename().endsWith('.csv'));assert(fs.readFileSync(await file.path(),'utf8').includes('theta_rad'));
 download=page.waitForEvent('download');await page.locator('[onclick="downloadJSON()"]').click();file=await download;const exported=JSON.parse(fs.readFileSync(await file.path(),'utf8'));assert(exported.data.length>2&&exported.units.theta==='rad');
 await page.locator('[onclick="clearHistory()"]').click();await page.waitForTimeout(50);assert(await page.evaluate(()=>lastFaultCapture===null));st=3;await page.waitForFunction(()=>robotState.st===4);assert(await page.evaluate(()=>lastFaultCapture?.fault==='SPEED_RAIL'));
 st=2;await page.waitForFunction(()=>robotState.st===2);await page.click('#btn-start');await down();await page.waitForTimeout(200);offline=true;await page.waitForFunction(()=>!socket.connected);await page.mouse.up();const count=commands.length;await page.waitForTimeout(400);assert.equal(commands.length,count);assert(!await up.evaluate(e=>e.classList.contains('is-pressed')));
 offline=false;await page.waitForFunction(()=>socket.connected);await page.waitForTimeout(300);assert(!commands.slice(count).some(c=>/^CMD,.*0\.050000/.test(c)));
 assert.equal(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth),true);await page.setViewportSize({width:1440,height:1000});await page.waitForTimeout(100);for(const id of ['panel-controls','panel-charts','panel-data'])assert(await page.locator('#'+id).isVisible());await page.screenshot({path:path.join(out,'desktop-direct.png'),fullPage:false});
 assert.deepEqual(errors,[]);assert.deepEqual(external,[]);
});
