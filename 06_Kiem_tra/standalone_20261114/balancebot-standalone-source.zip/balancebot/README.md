# Bản chính LQR + PID — lưu gyro và tự cân bằng (14/11/2026)

Mở `balancebot.ino` trong thư mục này; cần giữ tất cả file cùng thư mục. Không dùng các sketch `balancebot_lqr_only` hoặc `balancebot_lqr_60_test` cho chức năng mới này. Không thay gain LQR, PID 3/1/0.2, GPIO, cơ khí, giới hạn STEP/gia tốc/tốc độ.

## Hành vi

- Firmware **không tự hiệu chuẩn gyro khi bật nguồn**. Nó đọc bias đã lưu trong NVS `imu-cal-v1/gyro`, kiểm tra định dạng/CRC/WHO_AM_I/pin/trim và đối chiếu khoảng 0,5 giây dữ liệu tĩnh với bias đó. Không tính hay ghi lại bias trong bước kiểm tra.
- Chưa có bản lưu hợp lệ: `imu_diag=7`, motor tắt; phải chủ động hiệu chuẩn lần đầu trên web. Không có số bias đo từ xe thật được điền sẵn trong source này.
- Bật nguồn với dữ liệu hợp lệ: giữ cả pitch thô và pitch đã trừ zero trong **(-10°, +10°)**, tốc độ góc pitch/yaw nhỏ hơn 0,15 rad/s liên tục **5 giây**, xe tự chạy cân bằng, mục tiêu vận tốc/yaw bằng 0. Ra ngoài vùng, dữ liệu IMU cũ/không hợp lệ, chuyển động hoặc vòng xử lý bị gián đoạn sẽ đếm lại.
- Có thể bấm START thay vì chờ tự khởi động: vẫn cần IMU hợp lệ, pitch trong ±10° và qua trạng thái Arming 1 giây như cơ chế thủ công hiện có.
- Góc zero-corrected đạt **±40°**: lỗi `FALL`, motor tắt. Dựng lại dưới ±10° và ổn định đủ 5 giây thì tự xóa FALL và cân bằng lại với phiên lệnh mới; không khôi phục lệnh tiến/lùi/xoay cũ.
- **DỪNG/STOP**, ESTOP, RESET, hiệu chuẩn lại, SAVE hoặc chỉnh PID/zero sẽ hủy tự khởi động lại. Sau thao tác cấu hình hãy bấm START khi sẵn sàng, hoặc bật nguồn lại. RESET tự nó không bật motor.
- Chỉ FALL được tự phục hồi. IMU, SPEED_RAIL, DEADLINE, STEP_WATCHDOG, ESTOP và lỗi khởi tạo vẫn giữ lỗi, cần kiểm tra nguyên nhân rồi RESET/START riêng.
- Ngưỡng cho phép khởi động không chứng minh xe thật bắt được cân bằng ở 10°. Chưa thử bản này trên xe thật.

## Nạp và hiệu chuẩn thực tế một lần

1. Kê xe chắc và tắt nguồn motor khi nạp. Ngắt bridge/Serial Monitor khỏi COM, tự nạp sketch `balancebot.ino`.
2. Arduino: ESP32S3 Dev Module; Flash 16 MB; OPI PSRAM; USB Hardware CDC/JTAG và CDC On Boot Enabled theo cổng USB đã xác minh. **Erase All Flash Before Sketch Upload: Disabled** để giữ NVS.
3. Dừng server web cũ của dự án rồi mở lại `4_Web/Mo_Web.cmd` để bridge đọc hash cấu hình mới. Không dừng toàn bộ node.exe. Đóng Serial Monitor trước khi web mở COM.
4. Kết nối web với xe, bấm DỪNG, RESET nếu đang Fault. Giữ thân xe đứng yên, motor tắt. Bấm **Hiệu chuẩn gyro** và đợi “Hiệu chuẩn gyro đạt — đã lưu vào ESP32”. ACK pending chỉ là đã nhận lệnh.
5. `imu_calibrated=1, imu_cal_saved=1` mới xác nhận có kết quả thực tế đã lưu/đọc lại thành công. Nếu lỗi lưu (`imu_diag=8`) hoặc cửa sổ đo không đạt thì chưa sẵn sàng; không được giả trạng thái đạt.
6. Nếu cần đặt lại điểm zero, giữ đúng tư thế cân bằng, dùng Lấy góc và **Lưu vào xe** một lần. Gyro bias và PID/zero là hai bản lưu riêng. Bộ PID/zero từ hash ngay trước bản này được giữ qua thay đổi ngưỡng an toàn.
7. Kiểm tra góc/dấu motor với khung chống ngã trước. Bấm START cho lần thử đầu; không cần hiệu chuẩn lại sau mỗi START hoặc FALL.
8. Những lần bật nguồn sau chỉ cần dựng trong ±10° đủ 5 giây, hoặc bấm START. Muốn hiệu chuẩn lại: DỪNG, RESET nếu cần, giữ yên rồi bấm Hiệu chuẩn gyro. Nếu chỉ đổi firmware mà không xóa NVS và không đổi quy ước IMU thì bản lưu vẫn được dùng lại.

## Phạm vi đã kiểm chứng

Kiểm thử host/mocks và build không chứng minh cân bằng, chiều bánh, độ chính xác IMU, độ bền NVS khi mất nguồn hoặc thời gian vòng điều khiển trên xe thật. Gyro bias cần đo thực tế một lần sau khi tự nạp bản này; chưa đo trong phiên sửa code.

Source hiện có tại thời điểm bắt đầu sửa chưa chứa `WifiSettings.h` hoặc xử lý LQR2 trong firmware chính, dù web có các nút tương ứng. Bước này không khôi phục hai tính năng đó và không đồng nhất source này với binary bạn đang chạy trên xe. Kết nối AP/USB hiện có và luồng PID vẫn giữ theo source gốc đã sao lưu.
