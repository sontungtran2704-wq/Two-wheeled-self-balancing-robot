#pragma once
#include <cstddef>
#include <cstdint>
#include <cstring>
namespace wifi_settings {
struct Credentials {
  uint32_t version=1;
  char ssid[33]{};
  char password[64]{};
  bool valid() const {
    if(version!=1 || !std::memchr(ssid,0,sizeof ssid) || !std::memchr(password,0,sizeof password))return false;
    const size_t n=std::strlen(ssid),p=std::strlen(password);
    return n>0 && n<=32 && (p==0 || (p>=8 && p<=63));
  }
};
class Staging {
  Credentials value_{};
  uint8_t owner_=0;
  uint32_t since_=0;
  bool passwordReady_=false;
  static int hex(char c) {
    if(c>='0'&&c<='9')return c-'0';
    if(c>='a'&&c<='f')return c-'a'+10;
    if(c>='A'&&c<='F')return c-'A'+10;
    return -1;
  }
  static bool decode(const char* text,char* out,size_t capacity) {
    const size_t n=std::strlen(text);
    if(n%2 || n/2>=capacity)return false;
    for(size_t i=0;i<n;i+=2) {
      const int a=hex(text[i]),b=hex(text[i+1]);
      if(a<0||b<0||a*16+b<32||a*16+b==127)return false;
      out[i/2]=char(a*16+b);
    }
    out[n/2]=0;return true;
  }
 public:
  void clear(){value_={};owner_=0;passwordReady_=false;}
  const Credentials& value() const{return value_;}
  // Called only by the control task while disarmed. Credentials never appear in replies.
  const char* command(const char* line,uint8_t source,uint32_t now,bool idle,bool& commit) {
    commit=false;
    if(source!=1&&source!=2)return "ERR:OWNER";
    if(owner_ && uint32_t(now-since_)>10000000)clear();
    if(!idle){clear();return "ERR:STATE";}
    if(owner_ && owner_!=source)return "ERR:OWNER";
    if(!std::strncmp(line,"WIFI_SSID,",10)) {
      clear();
      if(!decode(line+10,value_.ssid,sizeof value_.ssid)||!value_.ssid[0]){clear();return "ERR:WIFI_SSID";}
      owner_=source;since_=now;return "ACK:WIFI_SSID";
    }
    if(!std::strncmp(line,"WIFI_PASS,",10)) {
      if(!owner_)return "ERR:WIFI_SEQUENCE";
      if(!decode(line+10,value_.password,sizeof value_.password)||!value_.valid()){clear();return "ERR:WIFI_PASSWORD";}
      passwordReady_=true;return "ACK:WIFI_PASS";
    }
    if(!std::strcmp(line,"WIFI_SAVE")) {
      if(!owner_||!passwordReady_||!value_.valid())return "ERR:WIFI_SEQUENCE";
      commit=true;return "ACK:WIFI_SAVED";
    }
    return "ERR:FORMAT";
  }
};
}
